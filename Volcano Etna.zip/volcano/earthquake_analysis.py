import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import geopandas as gpd
from shapely.geometry import Point, Polygon
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import ExponentialSmoothing
# Step 1: Load the data
earthquake_file = "Etna Earth quakes.csv"
earthquakes = pd.read_csv(earthquake_file)

# Step 2: Inspect the data
print("\nColumns in the dataset:", earthquakes.columns)
print("\nSample data:")
print(earthquakes.head())

# Step 3: Convert date and time columns into a single datetime object
def combine_datetime(row):
    return datetime(
        int(row['YEAR']), int(row['MONTH']), int(row['DAY']), 
        int(row['HOUR']), int(row['MINUET']), int(row['SECOND'])
    )

earthquakes['DATETIME'] = earthquakes.apply(combine_datetime, axis=1)

# Step 4: Plot earthquake magnitudes over time
plt.figure(figsize=(10, 6))
sns.lineplot(x='DATETIME', y='MAGNiTUDE', data=earthquakes, marker='o')
plt.title('Earthquake Magnitudes Over Time')
plt.xlabel('Date')
plt.ylabel('Magnitude')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

# Step 5: Spatial distribution of earthquakes
plt.figure(figsize=(10, 8))
plt.scatter(earthquakes['LON'], earthquakes['LAT'], c=earthquakes['MAGNiTUDE'], cmap='viridis', s=50)
plt.colorbar(label='Magnitude')
plt.title('Spatial Distribution of Earthquakes')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.grid(True)
plt.show()

# Step 6: Frequency of earthquakes by magnitude bins
bins = [0, 1, 2, 3, 4, 5]
earthquakes['Magnitude_Bin'] = pd.cut(earthquakes['MAGNiTUDE'], bins=bins, labels=['0-1', '1-2', '2-3', '3-4', '4-5'])

plt.figure(figsize=(8, 5))
sns.countplot(x='Magnitude_Bin', data=earthquakes, palette='coolwarm')
plt.title('Frequency of Earthquakes by Magnitude Range')
plt.xlabel('Magnitude Range')
plt.ylabel('Frequency')
plt.show()

# Step 7: Seasonal Patterns Analysis
# Add 'Month' and 'Season' columns
earthquakes['Month'] = earthquakes['DATETIME'].dt.month
earthquakes['Season'] = earthquakes['DATETIME'].dt.month % 12 // 3 + 1
earthquakes['Season'] = earthquakes['Season'].replace({1: 'Winter', 2: 'Spring', 3: 'Summer', 4: 'Autumn'})

# Group by Season and Month
seasonal_counts = earthquakes.groupby('Season').size()
monthly_counts = earthquakes.groupby('Month').size()

# Plot seasonal earthquake occurrences
plt.figure(figsize=(8, 5))
seasonal_counts.plot(kind='bar', color='teal')
plt.title('Earthquake Occurrences by Season')
plt.xlabel('Season')
plt.ylabel('Number of Earthquakes')
plt.grid(axis='y')
plt.show()

# Plot monthly earthquake occurrences
plt.figure(figsize=(10, 6))
monthly_counts.plot(kind='bar', color='orange')
plt.title('Earthquake Occurrences by Month')
plt.xlabel('Month')
plt.ylabel('Number of Earthquakes')
plt.grid(axis='y')
plt.xticks(ticks=range(12), labels=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.show()

# Step 8: Time Intervals Between Earthquakes
# Calculate time intervals
earthquakes = earthquakes.sort_values('DATETIME')
earthquakes['Time_Diff'] = earthquakes['DATETIME'].diff().dt.total_seconds() / 3600  # in hours

# Plot time interval distribution
plt.figure(figsize=(10, 6))
sns.histplot(earthquakes['Time_Diff'].dropna(), bins=50, kde=True, color='purple')
plt.title('Distribution of Time Intervals Between Earthquakes')
plt.xlabel('Time Interval (hours)')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()

# Step 9: Save the processed earthquake data
earthquakes.to_csv("Processed_Etna_Earthquakes.csv", index=False)
print("Processed earthquake data saved as 'Processed_Etna_Earthquakes.csv'")

# Temperature Data Analysis
# Step 1: Load the temperature data
temperature_file = "Catania_Temperature_2024.csv"
temperature_data = pd.read_csv(temperature_file)

# Step 2: Inspect the data
print("\nColumns in the dataset:", temperature_data.columns)
print("\nSample data:")
print(temperature_data.head())

# Step 3: Convert 'Date' to datetime format
temperature_data['Date'] = pd.to_datetime(temperature_data['Date'])

# Step 4: Plot high and low temperatures over time
plt.figure(figsize=(10, 6))
plt.plot(temperature_data['Date'], temperature_data['High Temperature (\u00b0C)'], label='High Temperature (°C)', color='red')
plt.plot(temperature_data['Date'], temperature_data['Low Temperature (\u00b0C)'], label='Low Temperature (°C)', color='blue')
plt.title('Daily High and Low Temperatures in Catania (2024)')
plt.xlabel('Date')
plt.ylabel('Temperature (°C)')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.show()

# Step 5: Check for anomalies (temperature differences exceeding a threshold)
temperature_data['Temp_Diff'] = temperature_data['High Temperature (\u00b0C)'] - temperature_data['Low Temperature (\u00b0C)']
anomalies = temperature_data[temperature_data['Temp_Diff'] > 15]

print("\nAnomalies (Temperature Difference > 15\u00b0C):")
print(anomalies)

# Step 6: Save the processed temperature data
temperature_data.to_csv("Processed_Catania_Temperature.csv", index=False)
print("Processed temperature data saved as 'Processed_Catania_Temperature.csv'")




population_file = "population.csv"
population_data = pd.read_csv(population_file)

# Step 2: Clean and preprocess the population data
# Remove commas from the 'Observation' column and convert to float for population data
population_data['Population'] = population_data['Observation'].replace({',': ''}, regex=True).astype(float)

# Step 3: Inspect the data to ensure the columns are correct
print("\nColumns in the dataset:", population_data.columns)
print("\nSample data:")
print(population_data.head())

# Step 4: Age and Gender Distribution
# Plot the distribution of age classes and gender
plt.figure(figsize=(10, 6))
sns.histplot(data=population_data, x='Age class', hue='Gender', multiple='stack', bins=30, palette='Set2')
plt.title('Age and Gender Distribution')
plt.xlabel('Age Class')
plt.ylabel('Population Count')
plt.grid(True)
plt.show()

# Step 5: Population Density Estimation
# If you have an 'Area_km2' column, calculate population density (population per square km)
# For the sake of this example, I'm assuming you have an 'Area_km2' column in the dataset. If not, you can skip this step or add a mock value for 'Area_km2'.

if 'Area_km2' in population_data.columns:
    population_data['Density'] = population_data['Population'] / population_data['Area_km2']

    # Plot the population density distribution
    plt.figure(figsize=(10, 6))
    sns.histplot(population_data['Density'], kde=True, color='green')
    plt.title('Population Density Across Catania')
    plt.xlabel('Population Density (people per km²)')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
else:
    print("Area_km2 column not found in the dataset. Please ensure the dataset includes area information.")
    

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Step 1: Load the eruption data
eruption_file = "evacuations.csv"
eruption_data = pd.read_csv(eruption_file)

# Step 2: Inspect the data
print("\nColumns in the dataset:", eruption_data.columns)
print("\nSample data:")
print(eruption_data.head())

# Step 3: Historical Eruption Analysis
# Eruption Types (with debugging)
if 'Type' in eruption_data.columns:
    plt.figure(figsize=(10, 6))
    sns.countplot(data=eruption_data, x='Type', palette='coolwarm')
    plt.title('Historical Eruptions by Type')
    plt.xlabel('Eruption Type')
    plt.ylabel('Count')
    plt.grid(True)
    plt.show()
else:
    print("Column 'Type' not found in the dataset. Available columns:", eruption_data.columns)

# VEI Distribution (with debugging)
if 'VEI' in eruption_data.columns:
    plt.figure(figsize=(10, 6))
    sns.histplot(data=eruption_data, x='VEI', bins=6, kde=False, color='coral')
    plt.title('Eruption VEI Distribution')
    plt.xlabel('Volcanic Explosivity Index (VEI)')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
else:
    print("Column 'VEI' not found in the dataset. Available columns:", eruption_data.columns)

# Duration Distribution (with debugging)
if 'Duration_hours' in eruption_data.columns:
    plt.figure(figsize=(10, 6))
    sns.histplot(data=eruption_data, x='Duration_hours', bins=20, kde=True, color='blue')
    plt.title('Eruption Duration Distribution')
    plt.xlabel('Duration (hours)')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
else:
    print("Column 'Duration_hours' not found in the dataset. Available columns:", eruption_data.columns)

# Step 4: Assess Affected Areas
if all(col in eruption_data.columns for col in ['Lava_Flow_Area_km2', 'Hazard_Zones', 'Ash_Fallout_km2']):
    plt.figure(figsize=(10, 6))
    plt.scatter(eruption_data['Lava_Flow_Area_km2'], eruption_data['Hazard_Zones'], 
                c=eruption_data['Ash_Fallout_km2'], cmap='plasma', s=50)
    plt.colorbar(label='Ash Fallout Area (km²)')
    plt.title('Affected Areas by Lava Flow and Hazard Zones')
    plt.xlabel('Lava Flow Area (km²)')
    plt.ylabel('Hazard Zones')
    plt.grid(True)
    plt.show()
else:
    print("One or more columns for affected area analysis are missing. Available columns:", eruption_data.columns)

# Step 5: Evacuation Success and Damage Severity
# Evacuation success analysis (with debugging)
if 'Evacuation_Success' in eruption_data.columns:
    plt.figure(figsize=(10, 6))
    sns.countplot(data=eruption_data, x='Evacuation_Success', palette='viridis')
    plt.title('Evacuation Success Rate')
    plt.xlabel('Evacuation Success (Yes/No)')
    plt.ylabel('Count')
    plt.grid(True)
    plt.show()
else:
    print("Column 'Evacuation_Success' not found in the dataset. Available columns:", eruption_data.columns)

# Damage Severity Distribution (with debugging)
if all(col in eruption_data.columns for col in ['Damage_Severity', 'VEI']):
    plt.figure(figsize=(10, 6))
    sns.boxplot(data=eruption_data, x='Damage_Severity', y='VEI', palette='muted')
    plt.title('Damage Severity vs VEI')
    plt.xlabel('Damage Severity')
    plt.ylabel('VEI')
    plt.grid(True)
    plt.show()
else:
    print("One or more columns for damage severity analysis are missing. Available columns:", eruption_data.columns)

# Save the processed eruption data
eruption_data.to_csv("Processed_Eruption_Data.csv", index=False)
print("Processed eruption data saved as 'Processed_Eruption_Data.csv'")



# Load earthquake data
earthquake_data = pd.read_csv(earthquake_file)
if 'LAT' in earthquake_data.columns and 'LON' in earthquake_data.columns:
    earthquake_data['geometry'] = earthquake_data.apply(lambda row: Point(row['LON'], row['LAT']), axis=1)
    earthquake_gdf = gpd.GeoDataFrame(earthquake_data, geometry='geometry')
else:
    print("Missing LAT or LON columns in earthquake data.")

# Load population data
population_data = pd.read_csv(population_file)
if 'LAT' in population_data.columns and 'LON' in population_data.columns:
    population_data['geometry'] = population_data.apply(lambda row: Point(row['LON'], row['LAT']), axis=1)
    population_gdf = gpd.GeoDataFrame(population_data, geometry='geometry')
else:
    print("Missing LAT or LON columns in population data.")

# Load eruption data
eruption_data = pd.read_csv(eruption_file)
if 'Hazard_Zones' in eruption_data.columns and 'Lava_Flow_Area_km2' in eruption_data.columns:
    eruption_gdf = gpd.GeoDataFrame(eruption_data)
else:
    print("Required columns for eruption data analysis are missing.")

# Step 2: Earthquake Hotspots
plt.figure(figsize=(10, 8))
earthquake_gdf.plot(ax=plt.gca(), color='red', markersize=5, label='Earthquakes')
plt.title('Earthquake Hotspots')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.legend()
plt.grid(True)
plt.show()

# Step 3: Lava Flow and Ash Fallout Zones
if 'geometry' in eruption_gdf.columns:
    eruption_gdf['geometry'] = eruption_gdf['Hazard_Zones'].apply(lambda x: Polygon(x) if isinstance(x, list) else None)
    eruption_gdf = gpd.GeoDataFrame(eruption_gdf, geometry='geometry')
    plt.figure(figsize=(10, 8))
    eruption_gdf.plot(ax=plt.gca(), color='orange', alpha=0.5, label='Hazard Zones')
    plt.title('Lava Flow and Ash Fallout Zones')
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.legend()
    plt.grid(True)
    plt.show()
else:
    print("Geometry data missing for eruption analysis.")

# Step 4: Population Density in At-Risk Areas
if 'Population' in population_data.columns:
    population_gdf['density'] = population_gdf['Population'] / population_gdf.geometry.area
    plt.figure(figsize=(10, 8))
    population_gdf.plot(column='density', ax=plt.gca(), cmap='Blues', legend=True, alpha=0.6, label='Population Density')
    plt.title('Population Density in At-Risk Areas')
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.legend()
    plt.grid(True)
    plt.show()
else:
    print("Population density calculation requires 'Population' column.")

# Step 5: Identify High-Risk Zones
if 'geometry' in eruption_gdf.columns and 'geometry' in population_gdf.columns:
    high_risk_areas = gpd.overlay(population_gdf, eruption_gdf, how='intersection')
    plt.figure(figsize=(10, 8))
    high_risk_areas.plot(ax=plt.gca(), color='red', alpha=0.7, label='High-Risk Zones')
    plt.title('High-Risk Zones')
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.legend()
    plt.grid(True)
    plt.show()
else:
    print("High-risk zone mapping requires valid geometry in both population and eruption datasets.")

print("Spatial analysis completed.")


