import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# Load the hazard data
df = pd.read_csv("mount_etna_volcanic_hazard_data.csv")

# Convert to GeoDataFrame
gdf = gpd.GeoDataFrame(
    df,
    geometry=gpd.points_from_xy(df['Longitude'], df['Latitude']),
    crs="EPSG:4326"
)

# Buffer sizes for hazard zones (in km)
buffer_sizes = {"High": 5.0, "Medium": 3.0, "Low": 1.5}

# Add buffer geometry to represent hazard zones
gdf["Hazard Buffer"] = gdf.apply(
    lambda row: row.geometry.buffer(buffer_sizes[row["Hazard Zones"]] / 110.574), axis=1
)

# Plot the hazard maps
fig, ax = plt.subplots(1, 2, figsize=(16, 8))

# Actual Hazard Map
for hazard_level, color in [("High", "red"), ("Medium", "yellow"), ("Low", "green")]:
    gdf[gdf["Hazard Zones"] == hazard_level].set_geometry("Hazard Buffer").plot(
        ax=ax[0], color=color, alpha=0.5, label=f"{hazard_level} Hazard"
    )
gdf.plot(ax=ax[0], color="black", markersize=10, label="Volcano")
ax[0].set_title("Actual Hazard Map")
ax[0].legend()

# Perceived Hazard Map (Evacuation Zones)
evacuation_gdf = gdf[gdf["Evacuation"] == "Yes"]
for hazard_level, color in [("High", "red"), ("Medium", "yellow"), ("Low", "green")]:
    evacuation_gdf[evacuation_gdf["Hazard Zones"] == hazard_level].set_geometry("Hazard Buffer").plot(
        ax=ax[1], color=color, alpha=0.5, label=f"{hazard_level} Evacuation Zone"
    )
gdf.plot(ax=ax[1], color="black", markersize=10, label="Volcano")
ax[1].set_title("Perceived Hazard Map (Evacuation Zones)")
ax[1].legend()

plt.show()


df = pd.read_csv("mount_etna_volcanic_hazard_data.csv")

# Load the earthquake data
earthquake_data = pd.read_csv("Etna Earth quakes.csv")

# Convert earthquake coordinates to Points (GeoDataFrame)
earthquake_gdf = gpd.GeoDataFrame(
    earthquake_data,
    geometry=gpd.points_from_xy(earthquake_data['LON'], earthquake_data['LAT']),
    crs="EPSG:4326"
)

# Convert volcanic hazard data to GeoDataFrame
volcanic_gdf = gpd.GeoDataFrame(
    df,
    geometry=gpd.points_from_xy(df['Longitude'], df['Latitude']),
    crs="EPSG:4326"
)

# Create hazard buffers (as before)
buffer_sizes = {
    "High": 5.0,
    "Medium": 3.0,
    "Low": 1.5
}

volcanic_gdf["Hazard Buffer"] = volcanic_gdf.apply(
    lambda row: row.geometry.buffer(buffer_sizes[row["Hazard Zones"]] / 110.574), axis=1
)

# Plotting
fig, ax = plt.subplots(figsize=(10, 8))

# Plot the volcanic hazard zones
for hazard_level, color in [("High", "red"), ("Medium", "yellow"), ("Low", "green")]:
    volcanic_gdf[volcanic_gdf["Hazard Zones"] == hazard_level].set_geometry("Hazard Buffer").plot(
        ax=ax, color=color, alpha=0.5, label=f"{hazard_level} Hazard"
    )

# Plot the volcano locations
volcanic_gdf.plot(ax=ax, color="black", markersize=10, label="Volcano")

# Plot the earthquake locations
earthquake_gdf.plot(ax=ax, color="blue", markersize=10, alpha=0.7, label="Earthquakes")

# Set plot title and legend``
ax.set_title("Volcanic Hazard Zones and Earthquake Locations")
ax.legend()

# Show plot
plt.show()





