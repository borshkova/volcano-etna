import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import numpy as np

# Step 1: Load the data into a Pandas DataFrame
file_path = "mount_etna_volcanic_hazard_data.csv"  # Replace with the path to your file
eruption_data = pd.read_csv(file_path)

# Display the first few rows of the dataset
print("Dataset Overview:")
print(eruption_data.head())

# Step 2: Convert to a GeoDataFrame
eruption_gdf = gpd.GeoDataFrame(
    eruption_data,
    geometry=gpd.points_from_xy(eruption_data["Longitude"], eruption_data["Latitude"]),
    crs="EPSG:4326"  # WGS84 coordinate system
)

# Verify GeoDataFrame structure
print("\nGeoDataFrame Overview:")
print(eruption_gdf.head())

# Step 3: Analyze Eruption Frequency Over Time
# Convert the 'Start Date' column to datetime format
eruption_data['Start Date'] = pd.to_datetime(eruption_data['Start Date'])

# Extract the year from the 'Start Date'
eruption_data['Year'] = eruption_data['Start Date'].dt.year

# Count the number of eruptions per year
eruption_frequency = eruption_data.groupby('Year').size()

# Plot the eruption frequency over time
plt.figure(figsize=(10, 6))
eruption_frequency.plot(kind='bar', color='lightcoral')
plt.title("Eruption Frequency per Year")
plt.xlabel("Year")
plt.ylabel("Number of Eruptions")
plt.xticks(rotation=45)
plt.show()

# Step 4: Filter for evacuations
evacuations = eruption_gdf[eruption_gdf["Evacuation"] == "Yes"]
print("\nEruptions Requiring Evacuation:")
print(evacuations)

# Step 5: Combined Visualization
fig, ax = plt.subplots(figsize=(12, 8))

# Plot eruption locations
eruption_gdf.plot(ax=ax, marker='o', color='red', alpha=0.5, label="Eruptions")

# Plot evacuations
evacuations.plot(ax=ax, marker='x', color='blue', alpha=0.7, label="Evacuations")

# Customize plot
plt.title("Eruption Locations with Evacuations Highlighted")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.legend()
plt.grid(True)

# Show the plot
plt.show()

# Step 6: Analyze Eruption Severity Over Time
# Group by year and calculate the average VEI per year to assess eruption severity
severity_by_year = eruption_data.groupby('Year')['VEI'].mean()

# Plot the average VEI over time
plt.figure(figsize=(10, 6))
severity_by_year.plot(kind='line', color='darkorange', marker='o')
plt.title("Average Eruption Severity (VEI) per Year")
plt.xlabel("Year")
plt.ylabel("Average VEI")
plt.xticks(rotation=45)
plt.show()

# Step 7: Identify High Activity Periods with Rolling Averages
# Compute a rolling average to smooth out the frequency and severity data
rolling_frequency = eruption_frequency.rolling(window=3).mean()
rolling_severity = severity_by_year.rolling(window=3).mean()

# Plot the rolling averages to identify trends
plt.figure(figsize=(12, 8))

# Frequency
plt.subplot(2, 1, 1)
plt.plot(rolling_frequency, color='lightcoral')
plt.title("Rolling Average of Eruption Frequency")
plt.xlabel("Year")
plt.ylabel("Average Number of Eruptions")

# Severity
plt.subplot(2, 1, 2)
plt.plot(rolling_severity, color='darkorange')
plt.title("Rolling Average of Eruption Severity (VEI)")
plt.xlabel("Year")
plt.ylabel("Average VEI")

plt.tight_layout()
plt.show()

# Optional: Predict Future Eruptions
# Prepare the data for linear regression (predicting eruption frequency)
X = np.array(eruption_frequency.index).reshape(-1, 1)  # Year
y = eruption_frequency.values  # Eruption count

# Create and train the model
model = LinearRegression()
model.fit(X, y)

# Make predictions for the next 5 years
future_years = np.array(range(2025, 2030)).reshape(-1, 1)
predictions = model.predict(future_years)

# Plot the predictions
plt.figure(figsize=(10, 6))
plt.plot(eruption_frequency.index, eruption_frequency, label='Historical Eruptions', color='lightcoral')
plt.plot(future_years, predictions, label='Predicted Eruptions', color='blue', linestyle='dashed')
plt.title("Eruption Frequency Prediction")
plt.xlabel("Year")
plt.ylabel("Number of Eruptions")
plt.legend()
plt.show()
